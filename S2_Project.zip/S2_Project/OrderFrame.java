/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalcy2cafe;

/**
 *
 * @author sarda
 */

import javax.swing.*;
import java.awt.event.*;

/**
 * OrderFrame Class
 * Order place karna, bill generate karna
 */
public class OrderFrame extends JFrame implements ActionListener {

    private JTextField  cname, cphone;
    private JComboBox<String> box;
    private JTextArea   billArea;
    private JButton     addO, billBtn, exitO;

    private Order currentOrder; // current order object

    public OrderFrame() {
        setTitle("Place Order");

        JLabel lName  = new JLabel("Customer Name:");
        lName.setBounds(20, 5, 130, 20);

        JLabel lPhone = new JLabel("Phone:");
        lPhone.setBounds(200, 5, 80, 20);

        cname  = new JTextField(); cname.setBounds(20,  25, 150, 30);
        cphone = new JTextField(); cphone.setBounds(200, 25, 150, 30);

        // Dropdown — menu se items lo
        box = new JComboBox<>();
        for (int i = 0; i < DataStore.menuModel.getRowCount(); i++) {
            String name  = DataStore.menuModel.getValueAt(i, 1).toString();
            String price = DataStore.menuModel.getValueAt(i, 2).toString();
            box.addItem(name + " - " + price);
        }
        box.setBounds(20, 80, 200, 30);

        billArea = new JTextArea();
        billArea.setEditable(false); // user wouldnot edit
        JScrollPane sp = new JScrollPane(billArea);
        sp.setBounds(20, 130, 340, 150);

        addO    = new JButton("Add Item");
        billBtn = new JButton("Generate Bill");
        exitO   = new JButton("Exit");

        addO.setBounds(240, 80, 100, 30);
        billBtn.setBounds(20,  290, 130, 30);
        exitO.setBounds(200, 290, 100, 30);

        addO.addActionListener(this);
        billBtn.addActionListener(this);
        exitO.addActionListener(this);

        add(lName); add(lPhone);
        add(cname); add(cphone);
        add(box);   add(addO);
        add(sp);
        add(billBtn); add(exitO);

        setSize(400, 380);
        setLayout(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // ITEM ADD
        if (e.getSource() == addO) {
            String selected = box.getSelectedItem().toString(); // "Burger - 500"
            billArea.append(selected + "\n");

            String[] parts = selected.split(" - ");
            if (parts.length == 2) {
                try {
                    double price = Double.parseDouble(parts[1].trim());

                    // Pehle item add se pehle Order object banao
                    if (currentOrder == null) {
                        currentOrder = new Order(cname.getText(), cphone.getText());
                    }
                    currentOrder.addItem(parts[0], price);

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Price format is wrong!");
                }
            }
        }

        // BILL GENERATE
        if (e.getSource() == billBtn) {

            // Order object banao ya update karo
            if (currentOrder == null) {
                currentOrder = new Order(cname.getText(), cphone.getText());
            } else {
                currentOrder.setCustomerName(cname.getText());
                currentOrder.setCustomerPhone(cphone.getText());
            }

            // Validation Order class se
            if (!currentOrder.isValid()) {
                JOptionPane.showMessageDialog(this, "Customer name, phone and item should be inserted");
                return;
            }

            billArea.append("\n--- BILL ---\n");
            billArea.append("Name:  " + currentOrder.getCustomerName()  + "\n");
            billArea.append("Phone: " + currentOrder.getCustomerPhone() + "\n");
            billArea.append("Items: " + currentOrder.getItems()         + "\n");
            billArea.append("Total: Rs. " + currentOrder.getTotal()     + "\n");

            // File mein save karo — FileManager ke zariye
            boolean saved = FileManager.saveOrder(currentOrder);

            // History model mein bhi add karo
            DataStore.custModel.addRow(new Object[]{
                currentOrder.getCustomerName(),
                currentOrder.getCustomerPhone(),
                currentOrder.getItems(),
                currentOrder.getTotal()
            });

            if (saved) {
                JOptionPane.showMessageDialog(this, "Order Saved!");
            } else {
                JOptionPane.showMessageDialog(this, "File Error — but order has been recorded.");
            }

            // Reset
            currentOrder = null;
            cname.setText("");
            cphone.setText("");
            billArea.setText("");
        }

        // EXIT
        if (e.getSource() == exitO) dispose();
    }
}
