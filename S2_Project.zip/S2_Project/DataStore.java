/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalcy2cafe;

/**
 *
 * @author sarda
 */


import javax.swing.table.DefaultTableModel;

/**
 * 
 */
public class DataStore {

    // ---- MENU MODEL ----
    public static DefaultTableModel menuModel;

    // ---- STAFF MODEL ----
    public static DefaultTableModel staffModel; //no copies will be generated

    // ---- CUSTOMER HISTORY MODEL ----
    public static DefaultTableModel custModel;

    // Static block — it is executed once when the program runs
    static {
        // Menu model setup
        menuModel = new DefaultTableModel(new String[]{"ID", "Name", "Price"}, 0);
        menuModel.addRow(new Object[]{"1", "Burger",  "500"});
        menuModel.addRow(new Object[]{"2", "Pizza",   "1200"});
        menuModel.addRow(new Object[]{"3", "Coffee",  "250"});

        // Staff model setup
        staffModel = new DefaultTableModel(new String[]{"ID", "Name", "Role"}, 0);
        staffModel.addRow(new Object[]{"1", "Hania", "Manager"});

        // Customer history model setup
        custModel = new DefaultTableModel(
            new String[]{"Customer", "Phone", "Items", "Bill"}, 0
        );
        FileManager.loadHistory(custModel); // file se history load karo
    }
}