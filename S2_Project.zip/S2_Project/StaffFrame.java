/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalcy2cafe;

/**
 *
 * @author sarda
 */

import javax.swing.*;
import java.awt.event.*;

/**
 * StaffFrame Class
 * Staff management — Add / Update / Delete
 */
public class StaffFrame extends JFrame implements ActionListener {

    private JTable     staffTable;
    private JTextField sid, sname, srole;
    private JButton    addS, updS, delS, exitS;

    public StaffFrame() {
        setTitle("Staff Management");

        staffTable = new JTable(DataStore.staffModel);
        JScrollPane sp = new JScrollPane(staffTable);
        sp.setBounds(20, 20, 300, 150);

        JLabel lId   = new JLabel("ID");   lId.setBounds(20,  178, 80, 18);
        JLabel lName = new JLabel("Name"); lName.setBounds(110, 178, 80, 18);
        JLabel lRole = new JLabel("Role"); lRole.setBounds(200, 178, 80, 18);

        sid   = new JTextField(); sid.setBounds(20,  196, 80, 30);
        sname = new JTextField(); sname.setBounds(110, 196, 80, 30);
        srole = new JTextField(); srole.setBounds(200, 196, 80, 30);

        addS  = new JButton("Add");
        updS  = new JButton("Update");
        delS  = new JButton("Delete");
        exitS = new JButton("Exit");

        addS.setBounds(20,  240, 70, 30);
        updS.setBounds(100, 240, 90, 30);
        delS.setBounds(200, 240, 90, 30);
        exitS.setBounds(120, 290, 80, 30);

        addS.addActionListener(this);
        updS.addActionListener(this);
        delS.addActionListener(this);
        exitS.addActionListener(this);

        add(sp);
        add(lId); add(lName); add(lRole);
        add(sid); add(sname); add(srole);
        add(addS); add(updS); add(delS); add(exitS);

        setSize(350, 400);
        setLayout(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // ADD
        if (e.getSource() == addS) {
            if (sid.getText().isEmpty() || sname.getText().isEmpty() || srole.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "fill allt the fields!");
                return;
            }
            DataStore.staffModel.addRow(new Object[]{
                sid.getText(), sname.getText(), srole.getText()
            });
            clearFields();
        }

        // UPDATE
        if (e.getSource() == updS) {
            int row = staffTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "select the row first from the table!");
                return;
            }
            DataStore.staffModel.setValueAt(sid.getText(),   row, 0);
            DataStore.staffModel.setValueAt(sname.getText(), row, 1);
            DataStore.staffModel.setValueAt(srole.getText(), row, 2);
            clearFields();
        }

        // DELETE
        if (e.getSource() == delS) {
            int row = staffTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "select the row first!");
                return;
            }
            DataStore.staffModel.removeRow(row);
        }

        // EXIT
        if (e.getSource() == exitS) dispose();
    }

    private void clearFields() {
        sid.setText("");
        sname.setText("");
        srole.setText("");
    }
}
