/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalcy2cafe;

/**
 *
 * @author sarda
 */

import javax.swing.*;
import java.awt.event.*;

/**
 * LoginFrame Class
 * Sirf login window ka kaam — username/password check karna
 */
public class LoginFrame extends JFrame implements ActionListener {

    private JTextField  userField;
    private JPasswordField passField;
    private JButton     loginBtn;

    public LoginFrame() {
        setTitle("Cafe System Login");

        JLabel u = new JLabel("Username");
        u.setBounds(50, 50, 100, 30);

        JLabel p = new JLabel("Password");
        p.setBounds(50, 100, 100, 30);

        userField = new JTextField();
        userField.setBounds(150, 50, 150, 30);

        passField = new JPasswordField();
        passField.setBounds(150, 100, 150, 30);

        loginBtn = new JButton("Login");
        loginBtn.setBounds(120, 160, 100, 30);
        loginBtn.addActionListener(this);

        add(u);
        add(p);
        add(userField);
        add(passField);
        add(loginBtn);

        setSize(400, 300);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == loginBtn) {

            String user = userField.getText();
            String pass = new String(passField.getPassword());

            if (user.equals("admin") && pass.equals("1234")) {
                // Owner login
                JOptionPane.showMessageDialog(this, "Owner Login Successful");
                new OwnerDashboard();
                dispose(); // login window band karo

            } else {
                // Customer login — koi bhi aa sakta hai
                JOptionPane.showMessageDialog(this, "Customer Login Successful");
                new CustomerDashboard();
                dispose();
            }
        }
    }
}
