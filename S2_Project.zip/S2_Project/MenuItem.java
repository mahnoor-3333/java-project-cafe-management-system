/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalcy2cafe;

/**
 *
 * @author sarda
 */

public class MenuItem {

    private String id;
    private String name;
    private double price;

    // Constructor
    public MenuItem(String id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    // Getters
    public String getId()    { return id; }
    public String getName()  { return name; }
    public double getPrice() { return price; }

    // Setters
    public void setId(String id)       { this.id = id; }
    public void setName(String name)   { this.name = name; }
    public void setPrice(double price) { this.price = price; }

    // toString — dropdown mein dikhane ke liye
    @Override
    public String toString() {
        return name + " - " + (int) price;
    }
}