/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalcy2cafe;

/**
 *
 * @author sarda
 */

public class Order {

    private String customerName;
    private String customerPhone;
    private String items;      // ordered items ki list (text)
    private double total;

    // Constructor
    public Order(String customerName, String customerPhone) {
        this.customerName  = customerName;
        this.customerPhone = customerPhone;
        this.items         = "";
        this.total         = 0;
    }

    // Item add karo order mein
    public void addItem(String itemName, double price) {
        items += itemName + " ";
        total += price;
    }

    // Reset karo (naya order)
    public void reset() {
        items = "";
        total = 0;
    }

    // Getters
    public String getCustomerName()  { return customerName; }
    public String getCustomerPhone() { return customerPhone; }
    public String getItems()         { return items.trim(); }
    public double getTotal()         { return total; }

    // Setters
    public void setCustomerName(String customerName)   { this.customerName  = customerName; }
    public void setCustomerPhone(String customerPhone) { this.customerPhone = customerPhone; }

    // File mein likhne ke liye CSV line banao
    public String toCsvLine() {
        return customerName + "," + customerPhone + "," + items.trim() + "," + total;
    }

    // Validation — sab fields bhare hain?
    public boolean isValid() {
        return !customerName.isEmpty() && !customerPhone.isEmpty() && !items.isEmpty();
    }
}
