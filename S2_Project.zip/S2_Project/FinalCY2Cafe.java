/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.finalcy2cafe;

/**
 *
 * @author sarda
 */
public class FinalCY2Cafe {

    public static void main(String[] args) {
        new LoginFrame();
    }
}
 
