/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalcy2cafe;

/**
 *
 * @author sarda
 */


import javax.swing.*;
import java.awt.event.*;

/**
 * HistoryFrame Class
 * Customer order history dikhana aur clear karna
 */
public class HistoryFrame extends JFrame implements ActionListener {

    private JTable  custTable;
    private JButton clearBtn, exitC;

    public HistoryFrame() {
        setTitle("Customer History");

        // Fresh load karo file se
        DataStore.custModel.setRowCount(0);
        FileManager.loadHistory(DataStore.custModel);

        custTable = new JTable(DataStore.custModel);
        JScrollPane sp = new JScrollPane(custTable);
        sp.setBounds(20, 20, 300, 180);

        clearBtn = new JButton("Clear History");
        exitC    = new JButton("Exit");

        clearBtn.setBounds(30,  220, 130, 30);
        exitC.setBounds(180, 220, 100, 30);

        clearBtn.addActionListener(this);
        exitC.addActionListener(this);

        add(sp);
        add(clearBtn);
        add(exitC);

        setSize(350, 310);
        setLayout(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // CLEAR HISTORY
        if (e.getSource() == clearBtn) {
            int confirm = JOptionPane.showConfirmDialog(
                this,
                "your history would be deleted — sure ?",
                "Confirm",
                JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                boolean done = FileManager.clearHistory();
                if (done) {
                    DataStore.custModel.setRowCount(0);
                    JOptionPane.showMessageDialog(this, "History is Clear ,now!");
                } else {
                    JOptionPane.showMessageDialog(this, "Error: History is not clear .");
                }
            }
        }

        // EXIT
        if (e.getSource() == exitC) dispose();
    }
}