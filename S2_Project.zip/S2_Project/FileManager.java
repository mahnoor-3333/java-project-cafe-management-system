/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalcy2cafe;

/**
 *
 * @author sarda
 */


import javax.swing.table.DefaultTableModel;
import java.io.*;

/**
 * FileManager Class
 * Saari file read/write operations yahan hain
 * (Single Responsibility Principle — sirf file ka kaam)
 */
public class FileManager {

    private static final String HISTORY_FILE = "history.txt";

    // History file se data load karo table model mein
    public static void loadHistory(DefaultTableModel model) {
        try {
            File f = new File(HISTORY_FILE);
            if (!f.exists()) return;

            BufferedReader br = new BufferedReader(new FileReader(f));
            String line;

            while ((line = br.readLine()) != null) {
                String[] d = line.split(",");
                if (d.length == 4) {
                    model.addRow(new Object[]{d[0], d[1], d[2], d[3]});
                }
            }
            br.close();

        } catch (Exception e) {
            System.out.println("History load error: " + e.getMessage());
        }
    }

    // Order save karo history file mein
    public static boolean saveOrder(Order order) {
        try (FileWriter w = new FileWriter(HISTORY_FILE, true)) {
            w.write(order.toCsvLine() + "\n");
            return true;
        } catch (Exception e) {
            System.out.println("Order save error: " + e.getMessage());
            return false;
        }
    }

    // History file clear karo
    public static boolean clearHistory() {
        try (FileWriter fw = new FileWriter(HISTORY_FILE, false)) {
            fw.write("");
            return true;
        } catch (Exception e) {
            System.out.println("Clear history error: " + e.getMessage());
            return false;
        }
    }
}