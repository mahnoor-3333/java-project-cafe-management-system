/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalcy2cafe;

/**
 *
 * @author sarda
 */

import javax.swing.*;
import java.awt.event.*;

/**
 * OwnerDashboard Class
 * Owner ka main menu — Menu, History, Staff, Logout
 */
public class OwnerDashboard extends JFrame implements ActionListener {

    private JButton menuBtn, customerBtn, staffBtn, exitBtn;

    public OwnerDashboard() {
        setTitle("Owner Dashboard");

        menuBtn     = new JButton("Menu Management");
        customerBtn = new JButton("Customer History");
        staffBtn    = new JButton("Staff Management");
        exitBtn     = new JButton("Logout");

        menuBtn.setBounds(100, 30, 180, 35);
        customerBtn.setBounds(100, 80, 180, 35);
        staffBtn.setBounds(100, 130, 180, 35);
        exitBtn.setBounds(100, 185, 180, 35);

        menuBtn.addActionListener(this);
        customerBtn.addActionListener(this);
        staffBtn.addActionListener(this);
        exitBtn.addActionListener(this);

        add(menuBtn);
        add(customerBtn);
        add(staffBtn);
        add(exitBtn);

        setSize(400, 290);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == menuBtn)     new MenuFrame(true);   // true = owner
        if (e.getSource() == customerBtn) new HistoryFrame();
        if (e.getSource() == staffBtn)    new StaffFrame();

        if (e.getSource() == exitBtn) {
            dispose();
            new LoginFrame(); // wapas login par jao
        }
    }
}
