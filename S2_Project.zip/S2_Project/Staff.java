/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalcy2cafe;

/**
 *
 * @author sarda
 */

public class Staff {

    private String id;
    private String name;
    private String role;

    // Constructor
    public Staff(String id, String name, String role) {
        this.id   = id;
        this.name = name;
        this.role = role;
    }

    // Getters
    public String getId()   { return id; }
    public String getName() { return name; }
    public String getRole() { return role; }

    // Setters
    public void setId(String id)     { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setRole(String role) { this.role = role; }
}
