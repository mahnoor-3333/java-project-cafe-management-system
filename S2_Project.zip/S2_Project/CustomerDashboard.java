/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalcy2cafe;

/**
 *
 * @author sarda
 */


import javax.swing.*;
import java.awt.event.*;

/**
 * CustomerDashboard Class
 * Customer ka main menu — Menu dekhna, Order karna, Logout
 */
public class CustomerDashboard extends JFrame implements ActionListener {

    private JButton menuBtn, orderBtn, exitBtn;

    public CustomerDashboard() {
        setTitle("Customer Dashboard");

        menuBtn  = new JButton("View Menu");
        orderBtn = new JButton("Place Order");
        exitBtn  = new JButton("Logout");

        menuBtn.setBounds(100, 50, 180, 35);
        orderBtn.setBounds(100, 105, 180, 35);
        exitBtn.setBounds(100, 160, 180, 35);

        menuBtn.addActionListener(this);
        orderBtn.addActionListener(this);
        exitBtn.addActionListener(this);

        add(menuBtn);
        add(orderBtn);//showing buttons.....
        add(exitBtn);

        setSize(400, 260);
        setLayout(null);//position set manually
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == menuBtn)  new MenuFrame(false); // false = customer (read-only)
        if (e.getSource() == orderBtn) new OrderFrame();//go to order frame for further info

        if (e.getSource() == exitBtn) {
            dispose();
            new LoginFrame(); // go back to login
        }
    }
}