/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalcy2cafe;

/**
 *
 * @author sarda
 */


import javax.swing.*;
import java.awt.event.*;

/**
 * MenuFrame Class
 * Menu window — owner ke liye add/update/delete
 *              customer ke liye sirf view
 */
public class MenuFrame extends JFrame implements ActionListener {

    private JTable    menuTable;
    private JTextField idF, nameF, priceF;
    private JButton   addM, updM, delM, exitM;
    private boolean   isOwner;

    public MenuFrame(boolean isOwner) {
        this.isOwner = isOwner;

        setTitle("Menu");

        // Table banao — DataStore se shared model use karo
        menuTable = new JTable(DataStore.menuModel);
        JScrollPane sp = new JScrollPane(menuTable);
        sp.setBounds(20, 20, 300, 150);
        add(sp);

        // Owner hai toh Add/Update/Delete dikhao
        if (isOwner) {
            JLabel lId    = new JLabel("ID");    lId.setBounds(20,  175, 80, 20);
            JLabel lName  = new JLabel("Name");  lName.setBounds(110, 175, 80, 20);
            JLabel lPrice = new JLabel("Price"); lPrice.setBounds(200, 175, 80, 20);

            idF    = new JTextField(); idF.setBounds(20,  195, 80, 30);
            nameF  = new JTextField(); nameF.setBounds(110, 195, 80, 30);
            priceF = new JTextField(); priceF.setBounds(200, 195, 80, 30);

            addM = new JButton("Add");
            updM = new JButton("Update");
            delM = new JButton("Delete");

            addM.setBounds(20,  235, 70, 30);
            updM.setBounds(100, 235, 80, 30);
            delM.setBounds(190, 235, 80, 30);

            addM.addActionListener(this);
            updM.addActionListener(this);
            delM.addActionListener(this);

            add(lId); add(lName); add(lPrice);
            add(idF); add(nameF); add(priceF);
            add(addM); add(updM); add(delM);
        }

        exitM = new JButton("Exit");
        exitM.setBounds(120, 275, 80, 30);
        exitM.addActionListener(this);
        add(exitM);

        setSize(350, 360);
        setLayout(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // ADD
        if (e.getSource() == addM) {
            if (idF.getText().isEmpty() || nameF.getText().isEmpty() || priceF.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "fill all the fields!");
                return;
            }
            DataStore.menuModel.addRow(new Object[]{
                idF.getText(), nameF.getText(), priceF.getText()
            });
            clearFields();
        }

        // UPDATE — pehle row select karo table mein, phir Update dabao
        if (e.getSource() == updM) {
            int row = menuTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "firstly, select the row from the table!");
                return;
            }
            DataStore.menuModel.setValueAt(idF.getText(),    row, 0);
            DataStore.menuModel.setValueAt(nameF.getText(),  row, 1);
            DataStore.menuModel.setValueAt(priceF.getText(), row, 2);
            clearFields();
        }

        // DELETE — pehle row select karo, phir Delete dabao
        if (e.getSource() == delM) {
            int row = menuTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "firstly, select the row from the table!");
                return;
            }
            DataStore.menuModel.removeRow(row);
        }

        // EXIT
        if (e.getSource() == exitM) dispose();
    }

    // Fields khali karo after action
    private void clearFields() {
        idF.setText("");
        nameF.setText("");
        priceF.setText("");
    }
}
